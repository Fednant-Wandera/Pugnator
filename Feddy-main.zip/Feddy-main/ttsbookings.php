<?php
$cn=ttsbookings('localhost','root') 