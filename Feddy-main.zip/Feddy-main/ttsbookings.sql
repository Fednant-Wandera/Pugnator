create database ttsbookings;
create table customertbl
(
    bookingid AUTO-INCREMENT,
    Fname char,
    Lname char,
    Gender char,
    Travel_Date date and time;
    startpoint char,
    Endpoint char,
    No_oftickets,

)bookingid primary key ;

